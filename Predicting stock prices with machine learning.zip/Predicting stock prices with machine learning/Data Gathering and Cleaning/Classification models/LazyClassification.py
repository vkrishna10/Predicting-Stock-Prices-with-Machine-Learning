#%%
from lazypredict.Supervised import LazyClassifier
from sklearn.model_selection import train_test_split
import pandas as pd
#%%
data = pd.read_csv('Feature_Engineering_v1.csv')
#%%

X = data[['totalRevenue',
   'totalLiabilities',
   'GDP',
   'Inflation',
   'Cons_Sent',
   'Cash_On_Hand',
   'Unemployment_Rate',
   'Recession_probability',
   'initialPrice']]


y= data[['class']]
#%%
X_train, X_test, y_train, y_test = train_test_split(X, y,test_size=.2,random_state =123)
#%%
clf = LazyClassifier(verbose=0,ignore_warnings=True, custom_metric=None)
models,predictions = clf.fit(X_train, X_test, y_train, y_test)

print(models)
#%%
from itertools import combinations
classifs = [[]]
for i in range(9, (len(X.columns)+1)):
    for combo in combinations(X.columns, (i)):

       X_temp = data[list(combo)]
       y = data[['class']]

       X_train, X_test, y_train, y_test = train_test_split(X_temp, 
                                                           y,test_size=.2,random_state =123)

       
       reg = LazyClassifier(verbose=0, ignore_warnings=False, custom_metric=None)
       models, predictions = reg.fit(X_train, X_test, y_train, y_test)
       print(models.iloc[0])
       classifs.append([combo, models.iloc[0]])
#%%
a = classifs[1:]

for index,val in enumerate(a):
       comp_min = 0
       min_index = -1
       for i in range(index, len(a),1):
              if a[i][1]['Accuracy'] > comp_min:
                     comp_min = a[i][1]['Accuracy']
                     min = a[i]
                     min_index = i
       temp = a[index]
       a[index] = min
       a[min_index] = temp
  
a
#%%
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.svm import NuSVC
import numpy as np

#Run a 10 fold crossvalidation on all of the models

sdg = SGDClassifier()
nb = GaussianNB()
pac = PassiveAggressiveClassifier()
svc = NuSVC()

scores_sdg = cross_val_score(sdg, X, y, cv=10)
print('Model 1 calculated')
scores_nb = cross_val_score(nb, X, y, cv=10)
print('Model 2 calculated')
scores_pac = cross_val_score(pac, X, y, cv=10)
print('Model 3 calculated')
scores_svc = cross_val_score(svc, X, y, cv=10)
print('Model 4 calculated')

print("""SGDClassifier Accuracy: %0.2f (+/- %0.2f)""" 
% (scores_sdg.mean(), ((scores_sdg.std() * 2.262)/np.sqrt(len(scores_sdg))) ) )

print("""GaussianNB Accuracy: %0.2f (+/- %0.2f)"""
% (scores_nb.mean(), ((scores_nb.std() * 2.262)/np.sqrt(len(scores_nb))) ) )

print("""PassiveAggressiveClassifier Accuracy: %0.2f (+/- %0.2f)"""
% (scores_pac.mean(), ((scores_pac.std() * 2.262)/np.sqrt(len(scores_pac))) ) )

print("""NuSVC Accuracy: %0.2f (+/- %0.2f)"""
% (scores_svc.mean(), ((scores_svc.std() * 2.262)/np.sqrt(len(scores_svc))) ) )
#%%
#Run a 10 fold crossvalidation on the PassiveAggressiveClassifier, GaussianNB, and SDGClassifier models for the F1 score
scores_sdg2 = cross_val_score(sdg, X, y, cv=10, scoring='f1_macro')
print('Model 1 calculated')
scores_nb2 = cross_val_score(nb, X, y, cv=10, scoring='f1_macro')
print('Model 2 calculated')
scores_pac2 = cross_val_score(pac, X, y, cv=10, scoring='f1_macro')
print('Model 3 calculated')

print("""SGDClassifier F1 Score: %0.2f (+/- %0.2f)"""
% (scores_sdg2.mean(), ((scores_sdg2.std() * 2.262)/np.sqrt(len(scores_sdg2))) ) )

print("""GaussianNB F1 Score: %0.2f (+/- %0.2f)"""
% (scores_nb2.mean(), ((scores_nb2.std() * 2.262)/np.sqrt(len(scores_nb2))) ) )

print("""PassiveAggressiveClassifier F1 Score: %0.2f (+/- %0.2f)"""
% (scores_pac2.mean(), ((scores_pac2.std() * 2.262)/np.sqrt(len(scores_pac2))) ) )

#%%
#create a confusion matrix for the passive aggressive classifier
from sklearn import metrics
import matplotlib.pyplot as plt
import seaborn as sns
# Create the Confusion Matrix
# y_test = dataframe['diagnosis']
y_pred = pac.predict(X_test)
cnf_matrix = metrics.confusion_matrix(y_test, y_pred)

# Visualizing the Confusion Matrix
class_names = [0,1] # Our diagnosis categories

fig, ax = plt.subplots()
# Setting up and visualizing the plot (do not worry about the code below!)
tick_marks = np.arange(len(class_names)) 
plt.xticks(tick_marks, class_names)
plt.yticks(tick_marks, class_names)
sns.heatmap(pd.DataFrame(cnf_matrix), annot=True, cmap="YlGnBu" ,fmt='g') 
ax.xaxis.set_label_position("top")
plt.tight_layout()
plt.title('Confusion matrix', y = 1.1)
plt.ylabel('Actual increase')
plt.xlabel('Predicted increase')

#%%
#                                   Accuracy  Balanced Accuracy  ROC AUC  F1 Score
# Model                                                                           
# SGDClassifier                      0.62               0.60     0.60      0.58   
# GaussianNB                         0.56               0.56     0.56      0.56   
# PassiveAggressiveClassifier        0.54               0.53     0.53      0.53   
# NuSVC                              0.52               0.52     0.52      0.52   
#%%
#Confidence Intervals - 95%
# SGDClassifier Accuracy: 0.50 (+/- 0.02)
# GaussianNB Accuracy: 0.50 (+/- 0.03)
# PassiveAggressiveClassifier Accuracy: 0.51 (+/- 0.01)
# NuSVC Accuracy: 0.48 (+/- 0.03)
# DecisionTreeClassifier Accuracy: 0.49 (+/- 0.03)
# RandomForestClassifier Accuracy: 0.48 (+/- 0.03)
# ExtraTreesClassifier Accuracy: 0.49 (+/- 0.03)
# KNeighborsClassifier Accuracy: 0.51 (+/- 0.04)
# RidgeClassifier Accuracy: 0.48 (+/- 0.03)
# Perceptron Accuracy: 0.49 (+/- 0.01)

#%%
# Ideal combination
#                                Accuracy  Balanced Accuracy  ROC AUC  F1 Score  \
# Model                                                                           
# SGDClassifier                      0.62               0.60     0.60      0.58   
# GaussianNB                         0.56               0.56     0.56      0.56   
# PassiveAggressiveClassifier        0.54               0.53     0.53      0.53   
# NuSVC                              0.52               0.52     0.52      0.52   

# %%
# multicollinearities not removed
# No feature engineering
# Data not normalized
# initial price not fed in
# Model                              Accuracy       Bal-Accuracy ROC AUC   F1 Score                                               
# AdaBoostClassifier                 0.55               0.55     0.55      0.55   
# Perceptron                         0.55               0.54     0.54      0.54   
# PassiveAggressiveClassifier        0.54               0.53     0.53      0.53   
# DecisionTreeClassifier             0.53               0.53     0.53      0.53   
# SVC                                0.54               0.53     0.53      0.52   
#%%
# multicollinearities not removed
# No feature engineering
# Normalized data
# initial price not fed in
#                                Accuracy  Balanced Accuracy  ROC AUC  F1 Score  \
# Model                                                                           
# Perceptron                         0.58               0.58     0.58      0.58   
# PassiveAggressiveClassifier        0.56               0.56     0.56      0.56   
# DecisionTreeClassifier             0.55               0.55     0.55      0.55   
# QuadraticDiscriminantAnalysis      0.55               0.54     0.54      0.55  
#%% 
# multicollinearities not removed
# No feature engineering
# Normalized data
# initial price fed in
#                                Accuracy  Balanced Accuracy  ROC AUC  F1 Score  \
# Model                                                                           
# SGDClassifier                      0.61               0.60     0.60      0.60   
# Perceptron                         0.56               0.56     0.56      0.56   
# GaussianNB                         0.55               0.54     0.54      0.54   
# PassiveAggressiveClassifier        0.54               0.52     0.52      0.52   
#%%
# multicollinearities removed
# No feature engineering
# Normalized data
# initial price fed in
#                                Accuracy  Balanced Accuracy  ROC AUC  F1 Score  \
# Model                                                                           
# DecisionTreeClassifier             0.55               0.55     0.55      0.55   
# ExtraTreeClassifier                0.54               0.54     0.54      0.54   
# KNeighborsClassifier               0.53               0.53     0.53      0.53   
# PassiveAggressiveClassifier        0.53               0.52     0.52      0.52   