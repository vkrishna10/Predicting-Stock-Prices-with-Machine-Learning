#%%
import pandas as pd
from lazypredict.Supervised import LazyRegressor
from sklearn.utils import shuffle
import numpy as np
import matplotlib.pyplot as plt
import sklearn
# %%
#read the contents of the csv file 'openBB_Data_v4_Normalized.csv' into a pandas dataframe
data = pd.read_csv('Feature_Engineering_v1.csv')
#%%
data['Delta'] = data['finalPrice'] - data['initialPrice']
# %%
X = data[['totalRevenue',
   'stockholderEquity',
   'totalLiabilities',
   'Asset/share',
   'GDP',
   'Inflation',
   'Cons_Sent',
   'Unemployment_Rate',
   'Recession_probability']]
# X = data[['totalRevenue', 'stockholderEquity', 'totalLiabilities', 'commonStockSharesOutstanding',
#        'Interest', 'SP', 'Cons_Sent', 'Fin_Stress', 'Cash_On_Hand',
#        'Unemployment_Rate']]

# X = data[['totalRevenue',  
#        'Interest', 'SP', 'Cons_Sent', 'Fin_Stress',
#        'Unemployment_Rate']]
#%%
from itertools import combinations
regs = [[]]
for i in range(9, (len(X.columns)+1)):
    for combo in combinations(X.columns, (i)):
       X_temp = data[list(combo)]
       y = data[['finalPrice']]

       X_temp, y =  shuffle(X_temp, y, random_state=42)
       X_temp = X_temp.astype(np.float32)
       offset = int(X_temp.shape[0] * 0.9)

       X_train, y_train = X_temp[:offset], y[:offset]
       X_test, y_test = X_temp[offset:], y[offset:]

       #reg = LazyRegressor(verbose=0, ignore_warnings=False, custom_metric=None)
       #create a new instance of LazyRegressor
       # exclude the following models: ['QuantileRegressor', 'NuSVR', 'SVR']
       reg = LazyRegressor(verbose=0, ignore_warnings=False, custom_metric=None)
       models, predictions = reg.fit(X_train, X_test, y_train, y_test)
       
       regs.append([combo, models.iloc[0]])
#%%
a = regs[1:]

for index,val in enumerate(a):
       comp_min = 0
       min_index = -1
       for i in range(index, len(a),1):
              if a[i][1]['Adjusted R-Squared'] > comp_min:
                     comp_min = a[i][1]['Adjusted R-Squared']
                     min = a[i]
                     min_index = i
       temp = a[index]
       a[index] = min
       a[min_index] = temp
  
a

# %%
y = data[['% delta']]
# %%
X, y =  shuffle(X, y, random_state=42)
#%%
X = X.astype(np.float32)

offset = int(X.shape[0] * 0.9)

X_train, y_train = X[:offset], y[:offset]
X_test, y_test = X[offset:], y[offset:]
# %%
reg = LazyRegressor(verbose=0, ignore_warnings=False, custom_metric=None)
                     
models, predictions = reg.fit(X_train, X_test, y_train, y_test)

print(models)
#%%
from sklearn.ensemble import ExtraTreesRegressor
tree = ExtraTreesRegressor()

# Run a 10 cross fold validation on tree using dataframes X and y
from sklearn.model_selection import cross_val_score
scores = cross_val_score(tree, X, y, cv=10)
scores

#print out the summary statistics for scores
print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))
#%%
#Do the same thing as the cell above, except for the following models:
#['LGBMRegressor', 'HistGradientBoostingRegressor', 'XGBRegressor']
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from sklearn.ensemble import BaggingRegressor
from sklearn.ensemble import HistGradientBoostingRegressor

xgb = XGBRegressor()
lgbm = LGBMRegressor()
bag = BaggingRegressor()
hist = HistGradientBoostingRegressor()

# Run a 10 cross fold validation on the models using dataframes X and y
from sklearn.model_selection import cross_val_score
scores_xgb = cross_val_score(xgb, X, y, cv=10)
scores_lgbm = cross_val_score(lgbm, X, y, cv=10)
scores_bag = cross_val_score(bag, X, y, cv=10)
scores_hist = cross_val_score(hist, X, y, cv=10)
#%%
#print out the square root of 2
print("ExtraTreesRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), (scores.std() * 2)/len(scores)))
print("XGBRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores_xgb.mean(), scores_xgb.std() * 2)/len(scores))
print("LGBMRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores_lgbm.mean(), scores_lgbm.std() * 2))
print("BaggingRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores_bag.mean(), scores_bag.std() * 2))
print("HistGradientBoostingRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores_hist.mean(), scores_hist.std() * 2))
#%%
# Create a 95% confidence interval for the score of all of the models and print it out
# print("""ExtraTreesRegressor Accuracy: %0.2f (+/- %0.2f)""" 
# % (scores.mean(), ((scores.std() * 2.262)/np.sqrt(len(scores))) ) )

print("""XGBRegressor Accuracy: %0.2f (+/- %0.2f)"""
% (scores_xgb.mean(), ((scores_xgb.std() * 2.262)/np.sqrt(len(scores_xgb))) ) )

print("""LGBMRegressor Accuracy: %0.2f (+/- %0.2f)"""
% (scores_lgbm.mean(), ((scores_lgbm.std() * 2.262)/np.sqrt(len(scores_lgbm))) ) )

print("""BaggingRegressor Accuracy: %0.2f (+/- %0.2f)"""
% (scores_bag.mean(), ((scores_bag.std() * 2.262)/np.sqrt(len(scores_bag))) ) )

print("""HistGradientBoostingRegressor Accuracy: %0.2f (+/- %0.2f)"""
% (scores_hist.mean(), ((scores_hist.std() * 2.262)/np.sqrt(len(scores_hist))) ) )

#%%
#Run a 10 cross fold validation for the following models: LGBMRegressor, SGDRegressor, RandomForestRegressor.  for adjusted r-squared and RMSE
from sklearn.linear_model import SGDRegressor
from sklearn.ensemble import RandomForestRegressor
from lightgbm import LGBMRegressor

sgd = SGDRegressor()
rf = RandomForestRegressor()
lgbm = LGBMRegressor()

# Run a 10 cross fold validation on the models using dataframes X and y
from sklearn.model_selection import cross_val_score
scores_sgd = cross_val_score(sgd, X, y, cv=10)
scores_rf = cross_val_score(rf, X, y, cv=10)
scores_lgbm = cross_val_score(lgbm, X, y, cv=10)

#print out the summary statistics for scores
print("SGDRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores_sgd.mean(), scores_sgd.std() * 2))
print("RandomForestRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores_rf.mean(), scores_rf.std() * 2))
print("LGBMRegressor Accuracy: %0.2f (+/- %0.2f)" % (scores_lgbm.mean(), scores_lgbm.std() * 2))

#%%
# Plot the relation between '% delta' and 'totalRevenue' using a scatter plot, draw a line of best fit
# and print out the r-squared value
import seaborn as sns
sns.regplot(x='Asset/share', y='finalPrice', data=data)
plt.show()


#%%

# #%%
# Model                                                                              
# LGBMRegressor                                                              -0.12   
# SGDRegressor                                                               -0.12   
# RandomForestRegressor                                                      -0.13   
# TweedieRegressor                                                           -0.13  
#%%
# 95% confidence interval for the score of all of the models
# ExtraTreesRegressor Accuracy: 0.84 (+/- 0.03)
# XGBRegressor Accuracy: 0.82 (+/- 0.03)
# LGBMRegressor Accuracy: 0.81 (+/- 0.03)
# BaggingRegressor Accuracy: 0.79 (+/- 0.03)
# HistGradientBoostingRegressor Accuracy: 0.82 (+/- 0.03)
#%%
#Ideal combination of features
#                                Adjusted R-Squared  R-Squared   RMSE  \
# Model                                                                 
# ExtraTreesRegressor                          0.89       0.90  38.44   
# LGBMRegressor                                0.80       0.82  51.19   
# XGBRegressor                                 0.79       0.81  52.14   
# HistGradientBoostingRegressor                0.75       0.77  57.25   
# %%
# Not normalized
# No models had a positive R2 score 
# initial price not fed in
# asked to find the delta

#%%
# Not normalized
#                                Adjusted R-Squared  R-Squared     RMSE  \
# Model                                                                   
# BaggingRegressor                             0.86       0.88    41.63   
# RandomForestRegressor                        0.84       0.87    43.32   
# HistGradientBoostingRegressor                0.82       0.85    46.26   
# LGBMRegressor                                0.81       0.84    47.49   
#%%

# Normalized
# Asked to find final price
# Not fed in initial price data
#                                Adjusted R-Squared  R-Squared   RMSE  \
# Model                                                                 
# BaggingRegressor                             0.89       0.90  37.26   
# XGBRegressor                                 0.88       0.89  38.91   
# RandomForestRegressor                        0.86       0.88  40.68   
# HistGradientBoostingRegressor                0.84       0.86  44.20   

#%% 
#  Normalized
#X = data[['totalRevenue', 'stockholderEquity', 'commonStockSharesOutstanding', 
       # 'Interest', 'SP', 'Cons_Sent', 'Fin_Stress', 'Cash_On_Hand',
       # 'Unemployment_Rate']]
#                                Adjusted R-Squared  R-Squared   RMSE  \
# Model                                                                 
# XGBRegressor                                 0.88       0.89  39.63   
# RandomForestRegressor                        0.83       0.84  47.39   
# LGBMRegressor                                0.82       0.84  48.38   
# HistGradientBoostingRegressor                0.81       0.83  49.86   
# BaggingRegressor                             0.80       0.82  50.61   
#%%
#  Normalized
#X = data[['Liab/Rev', 'Asset/share', 
       # 'Interest', 'SP', 'Cons_Sent', 'Fin_Stress', 'Cash_On_Hand',
       # 'Unemployment_Rate']]
#                                Adjusted R-Squared  R-Squared     RMSE  \
# Model                                                                   
# BaggingRegressor                             0.72       0.74    60.89   
# LGBMRegressor                                0.70       0.73    62.40   
# RandomForestRegressor                        0.69       0.72    63.83   
# HistGradientBoostingRegressor                0.67       0.70    66.09 
#%%   
#  Normalized
#X = data[['Liab/Rev', 'totalAssets', 
       # 'Interest', 'SP', 'Cons_Sent', 'Fin_Stress', 'Cash_On_Hand',
       # 'Unemployment_Rate']]
#%%
# from sklearn.ensemble import BaggingRegressor
# bag = BaggingRegressor()
# bag.fit(X_train, y_train)
# y_pred = bag.predict(X_test)
# import sklearn.metrics as metrics
# r2 = metrics.r2_score(y_test,y_pred)
# r2
#%%
# Create a correlation matrix (with plots) to see if there is any multicollinearity
import seaborn as sns
import matplotlib.pyplot as plt
# matrix = X.corr().round(1)
# sns.heatmap(data=matrix, annot=True)
# plt.show()
# %%
# Create a correlation matrix to see which features are most correlated with the target variable
Xp = data[['totalRevenue',
   'stockholderEquity',
   'totalLiabilities',
   'Asset/share',
   'GDP',
   'Inflation',
   'Cons_Sent',
   'Unemployment_Rate',
   'Recession_probability',
       'finalPrice']]
corr_matrix = Xp.corr().round(1)
sns.heatmap(data=corr_matrix, annot=True, vmax=1, vmin=-1, center=0, cmap='vlag', mask=np.triu(np.ones_like(corr_matrix, dtype=bool)))
plt.show()
# %%
plt.savefig('collinearities.png')
# %%
