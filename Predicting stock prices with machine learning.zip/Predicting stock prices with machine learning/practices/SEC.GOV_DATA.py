#%%
import requests as rq
import time
import pandas as pd
import json
import math
# %%
headers = {'User-Agent': "vkrishnaswamy489@gmail.com"}
tickers_cik = rq.get("https://www.sec.gov/files/company_tickers.json", headers=headers)
# %%
tickers_cik =     pd.json_normalize(pd.json_normalize(tickers_cik.json(),\
max_level=0).values[0])
tickers_cik["cik_str"] = tickers_cik["cik_str"].astype(str).str.zfill(10)
tickers_cik.set_index("ticker",inplace=True)
# %%
tickers_cik.sort_index()
# %%
companies = ['NVDA', 'TSLA', 'META', 'NFLX', 'CRM', 'AMD', 'INTC', 'PYPL', 'ATVI', 'EA', 'TTD',
    'MTCH', 'ZG', 'YELP', 'CSCO', 'ADBE', 'AGYS', 'MCHP', 'PD', 'DOCU', 'BOX', 'PRO',
    'VRNS', 'AYX', 'SMAR', 'AVGO', 'ACN', 'TXN', 'ORCL', 'MSFT', 'DELL', 'AMZN',
    'GOOG', 'AAPL', 'VZ', 'T', 'CMCSA', 'TMUS', 'RTX', 'SNX', 'IBM', 'HPQ', 'CHTR', 'QCOM', 'BBY', 'FISV', 
    'CTSH', 'DISH', 'ADI', 'ADP']
companies = ['NVDA']
# %%
comp_cik = []

for company in companies:
    try:
        comp_cik.append(tickers_cik.at[company, 'cik_str'])
    except KeyError:
        print(company)
#%%
params = ['Assets', 'Liabilities', 'StockholdersEquity', 'InventoryNet',
          'CostOfGoodsAndServicesSold', 'GrossProfit', 'WeightedAverageNumberOfSharesOutstandingBasic',
          ]
# 'CommonStockDividendsPerShareCashPaid'
params = ['Liabilities']
# %%
others = ['Name', 'Date']
df = pd.DataFrame(columns=(others+params))
#%%
df = pd.DataFrame(columns=(others+params))

num_per = 20

for ind, cik in enumerate(comp_cik):

    url_string = "https://data.sec.gov/api/xbrl/companyfacts/CIK" + cik + ".json"
    response = rq.get(url_string, headers=headers)
    time.sleep(.1)
    print(response.json())
    a = response.json()
    length = len(df)
    for i in range(0,num_per,1):
        df.loc[len(df)]={}
    for num, param in enumerate(params):
        print('Current param:', param, sep=' ')
        try:
            new_row = {'Name':companies[ind]}
            try:
                timeseries = pd.json_normalize(response.json()['facts']['us-gaap'][param]["units"]["USD"])
            except KeyError:
                try:
                    timeseries = pd.json_normalize(response.json()['facts']['us-gaap'][param]["units"]["shares"])
                except KeyError:
                    timeseries = pd.json_normalize(response.json()['facts']['us-gaap'][param]["units"]["USD/shares"])
                    
            timeseries["filed"] = pd.to_datetime(timeseries["filed"])
            try:
                timeseries["start"] = pd.to_datetime(timeseries["start"])
                timeseries["end"] = pd.to_datetime(timeseries["end"])
            except Exception:
                pass

            timeseries['frame'] = timeseries['frame'].fillna(0)
            print(timeseries.tail(20))

# timeseries.at[j,'fp']=='FY' or timeseries.at[j,'form']=='10-K'  or timeseries.at[j,'frame']==0 or timeseries.at[j,'frame'][-2]!='Q'

            for j in range(len(timeseries.index)-1, -1, -1):
                if j == len(timeseries.index)-1:
                    pass
                    # if timeseries.at[j,'form']=='10-K':
                    #     timeseries = timeseries.drop(j)
                    #     timeseries = timeseries.reset_index(drop=True)
                else: 
                    if timeseries.at[j,'form']=='10-K' or timeseries.at[j, 'end']==timeseries.at[(j+1), 'end']:
                        # print(timeseries.tail(10))
                        timeseries = timeseries.drop(j)
                        timeseries = timeseries.reset_index(drop=True)
                        # print(timeseries.tail(10))
            print(timeseries.tail(20))

            timeseries2 = timeseries.sort_values(by='filed', ascending=False).groupby(['end', 'fp','form']).head(1).sort_values('filed').reset_index(drop=True)
        # except:
        #     pass

            

            for i in range(0,num_per,1):
                new_row['Date'] = timeseries.at[(len(timeseries.index)-i-1), 'end']
                new_row[param] = timeseries.at[(len(timeseries.index)-i-1), 'val']
                df.at[length+i, 'Name'] = companies[ind]
                df.at[length+i, 'Date'] = timeseries.at[(len(timeseries.index)-i-1), 'end']
                df.at[length+i, param] = timeseries.at[(len(timeseries.index)-i-1), 'val']
        except Exception:
            pass
        
    print('Number of companies:',(ind+1),sep=' ')
        
#df
# %%
import openpyxl
#%%
df.to_csv("sec_data_final.csv",mode='w')

# %%
df['CommonStockDividendsPerShareCashPaid'] = df['CommonStockDividendsPerShareCashPaid'].fillna(0)
# %%
df.to_csv("sec_data_final.csv",mode='a')

# %%
df= pd.read_csv("sec_data_final.csv", header=0)
# %%
num_empty = df['Assets'].isna().sum()

print(f"Number of empty cells in column \'Assets\': {num_empty}")
#%%
df['Assets'] = df['Assets'].fillna(0)
for i in range(0, len((df))):
    if df.at[i, 'Assets']==0:
        try:
            df.at[i, 'Assets'] = df.at[i, 'StockholdersEquity'] + df.at[i, 'Liabilities']
        except Exception:
            pass
#%%
num_empty = df['Assets'].isna().sum()

print(f"Number of empty cells in column \'Assets\': {num_empty}")

# %%

# %%
