#%%
import yfinance as yf
import pandas as pd
import numpy as np
#%%
msft_data = yf.download("MSFT", start="2018-01-01", end="2020-02-21", interval="1mo")
#%%
type(msft_data)
# %%
msft_data.head()
# %%
# msft_data["Market Cap"]
#%%

msft_2 = yf.Ticker("MSFT")

# %%
m_hist = msft_2.history(period='2y')
# %%
m_hist.head()
# %%
m_hist.shape
# %%
m_hist["Market Cap"]

# %%
msft_2.info["sharesOutstanding"]

# %%
