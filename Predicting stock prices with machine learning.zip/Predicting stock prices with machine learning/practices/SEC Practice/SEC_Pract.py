#%%
import requests
import json
import pandas as pd
# %%
key = "3f6bd979f87045f14249e28807069f86ddd92cc593e38d3a07f7fe4c9402f5ec"
#%%
params = {
    "url":"https://www.sec.gov/Archives/edgar/data/789019/000156459022015675/msft-10q_20220331.htm",
    "item":"part1item1",
    "type":"json",
    "token": key
    }

# %%
# url_list = ["https://api.sec-api.io/extractor?url=",
#         params["url"],
#         "&item=" ,
#         params["item"],
#         "&type=",
#         params["type"],
#         "&token=",
#         key
#     ]

url_list = ["https://api.sec-api.io/xbrl-to-json?htm-url=",
        params["url"],
        "&token=",
        key
    ]

#%%
url_str = ""
for mini_url in url_list:
    url_str += mini_url
#%%
url_str
#%%
new_url = "https://api.sec-api.io/xbrl-to-json?htm-url=https://www.sec.gov/Archives/edgar/data/789019/000156459022015675/msft-10q_20220331.htm&token=3f6bd979f87045f14249e28807069f86ddd92cc593e38d3a07f7fe4c9402f5ec"
response = requests.get(new_url)
# %%
status = response.status_code
# %%
status
# %%
print(response.json())

# %%
from sec_api import QueryApi
# %%
queryApi = QueryApi(api_key=key)

query = {
    "query": {
        "query_string": {
            "query": "ticker:MSFT AND formType:\"10-Q\""
        }
    },
    "from": "0",
    "size": "10",
    "sort": [
        {
            "filedAt": {
                "order": "desc"
            }
        }
    ]
}
#%%
response = queryApi.get_filings(query)
# %%
metadata = pd.DataFrame.from_records(response['filings'])
print(metadata)
#%%
for i in range(0,(len(response["filings"])-1) ):
    print(json.dumps(response["filings"][i], indent=2))
# %%
metadata.head(4)
# %%
metadata["accessionNo"]
# %%
metadata["periodOfReport"]

# %%
metadata.shape

# %%
metadata["cik"].get(0)

# %%
acc_num = str(metadata['accessionNo'].get(0)).replace("-","")
acc_num

# %%
date_str = str(metadata['periodOfReport'].get(0)).replace("-", "")
date_str
# %%
acc_num = str(metadata['accessionNo'].get(0)).replace("-","")
date_str = str(metadata['periodOfReport'].get(0)).replace("-", "")
url_str = "https://www.sec.gov/Archives/edgar/data/" + metadata["cik"].get(0) + "/" + acc_num + "/" + "msft" + "-10q_" +  date_str + ".htm"
param = {
    "url":url_str,
    "item":"part1item1",
    "type":"html",
    "token":key
}
response = requests.get("https://api.sec-api.io/extractor?" + "url=" + param["url"] + "&item=" + param["item"] + "&type=" + param["type"] + "&token=" + param["token"])
response.status_code
# %%
import html_to_json
# %%
output = html_to_json.convert(response)
output

# %%
from sec_api import XbrlApi
# %%
xbrlApi = XbrlApi(key)
xbrl_json = xbrlApi.xbrl_to_json(htm_url=url_str)
# %%
xbrl_json

# %%
msft_fin = pd.json_normalize(xbrl_json['StatementsOfIncome']["NonoperatingIncomeExpense"])


# %%
msft_fin.head()
# %%
type(msft_fin)
# %%
msft_fin.head(1)

# %%

msft_bal = pd.json_normalize(xbrl_json["BalanceSheets"])

# %%
msft_bal.head()
# %%
list(msft_bal)
# %%
msft_inc = pd.json_normalize(xbrl_json["StatementsOfIncome"])

# %%
msft_inc.head()
# %%
list(msft_inc)

# %%
msft_cash = pd.json_normalize(xbrl_json["StatementsOfCashFlows"])
list(msft_cash)
# %%
df = pd.DataFrame([[0]*9], columns=['Name', 'Start', 'End', 'Assets', 'Liabilities', 'Equity', 'NetInventory', 
                                    'EPS', 'CostOfGoodsAndServicesSold', 
                                    'GrossProfit', 'BasicSharesOutstanding', 'DividendPayments'])
# %%
print(df)
# %%
df.at[0, 'Assets'] = msft_bal.loc[0, "Assets"]
# %%
msft_bal["Assets"][0][0]['value']
# %%
df.at[0, 'Assets'] = msft_bal["Assets"][0][0]['value']

# %%
df.head()
# %%
df.at[0, 'Liabilities'] = msft_bal['Liabilities'][0][0]['value']
df.head()
# %%
list(msft_inc)
# %%
df.at[0, 'EPS'] = msft_inc['EarningsPerShareBasic'][0][0]['value']
df.head()
# %%
msft_inc['EarningsPerShareBasic'][0][0]
# %%
df.at[0, 'DividendPayments'] = msft_ca['PaymentsOfDividendsCommonStock'][0][0]['value']
df.head()
# %%
