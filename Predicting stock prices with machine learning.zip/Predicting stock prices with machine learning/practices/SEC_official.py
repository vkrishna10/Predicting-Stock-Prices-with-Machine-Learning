#%%
import requests as rq
import time
import pandas as pd
import json
# %%
headers = {'User-Agent': "vkrishnaswamy489@gmail.com"}
# %%
tickers_cik = rq.get("https://www.sec.gov/files/company_tickers.json", headers=headers)
# %%
tickers_cik =     pd.json_normalize(pd.json_normalize(tickers_cik.json(),\
max_level=0).values[0])
tickers_cik["cik_str"] = tickers_cik["cik_str"].astype(str).str.zfill(10)
tickers_cik.set_index("ticker",inplace=True)
# %%
tickers_cik.sort_index()
# %%
companies = ['NVDA', 'TSLA', 'META', 'BABA', 'CRM', 'AMD', 'INTC', 'PYPL', 'ATVI', 'EA', 'TTD',
    'MTCH', 'ZG', 'YELP', 'CSCO', 'ADBE', 'AGYS', 'MCHP', 'PD', 'DOCU', 'BOX', 'PRO',
    'VRNS', 'AYX', 'SMAR', 'AVGO', 'ACN', 'TXN', 'ORCL', 'MSFT', 'DELL', 'AMZN',
    'GOOG', 'AAPL', 'VZ', 'T', 'CMCSA', 'TMUS', 'RTX', 'SNX', 'IBM', 'HPQ', 'CHTR', 'QCOM', 'BBY', 'FISV', 
    'CTSH', 'DISH', 'ADI', 'ADP']
companies=['NVDA']
# %%
comp_cik = []

for company in companies:
    try:
        comp_cik.append(tickers_cik.at[company, 'cik_str'])
    except KeyError:
        print(company)
#%%
params = ['Assets', 'Liabilities', 'StockholdersEquity', 'InventoryNet',
          'CostOfGoodsAndServicesSold', 'GrossProfit', 'WeightedAverageNumberOfSharesOutstandingBasic',
          'CommonStockDividendsPerShareCashPaid']
params = ['Assets']
#params = ['CostOfGoodsAndServicesSold', 'CommonStockDividendsPerShareCashPaid']
#%%
others = ['Name', 'Date']
df = pd.DataFrame(columns=(others+params))
n=0
num_quarters=5
num_runs=0

for i in range(0,len(comp_cik)):
    num_runs=0
    
    while num_runs != num_quarters:
        k=0

        for param in params:

            new_row = {
            'Name':companies[i],
            }

            url_string = "https://data.sec.gov/api/xbrl/companyconcept/CIK" + comp_cik[i] + "/us-gaap/" + param + ".json"
            response = rq.get(url_string, headers=headers)
            print(response.json())
            #time.sleep(0.07)

            try:

                try:
                    timeseries = pd.json_normalize(response.json()["units"]["USD"])
                except KeyError:
                    try:
                        timeseries = pd.json_normalize(response.json()["units"]["shares"])
                    except KeyError:
                        timeseries = pd.json_normalize(response.json()["units"]["USD/shares"])
                        
                timeseries["filed"] = pd.to_datetime(timeseries["filed"])
                try:
                    timeseries["start"] = pd.to_datetime(timeseries["start"])
                    timeseries["end"] = pd.to_datetime(timeseries["end"])
                except Exception:
                    pass

                timeseries.tail()
                timeseries = timeseries.sort_values("end")
                timeseries.tail()
                
                for j in range(len(timeseries.index)-1, len(timeseries.index)-2-num_quarters, -1):
                    try:
                        if timeseries.at[j,'start'].month == timeseries.at[j,'end'].month:
                            timeseries = timeseries.drop(j)
                            timeseries = timeseries.reset_index(drop=True)
                            # print(timeseries.tail())
                    except KeyError or AttributeError:
                        if timeseries.at[j,'fp'] =='FY':
                            timeseries = timeseries.drop(j)
                            timeseries = timeseries.reset_index(drop=True)
                            # print(timeseries.tail())
                # new_row['start'] = timeseries.at[(len(timeseries.index)-k-1), 'start']
                if (df['Date'] == timeseries['end'][(len(timeseries.index)-k-1)]).any():
                    k+=1                  
                else:
                    new_row['Date'] = timeseries.at[(len(timeseries.index)-k-1), 'end']
                    new_row[param] = timeseries.at[(len(timeseries.index)-k-1), 'val']
                    df.loc[len(df)] = new_row
                    num_runs+=1
                    k+=1

            except Exception as e:
                n+=1
                
        print('Number of Rows: ', num_runs)
        # new_row = None
    print('Number of Companies:', i, sep=' ')
    print('Number of Empty Values:', n, sep=' ')
    

df
        
# %%
import openpyxl
#%%
df.to_csv("trial.csv",mode='a')
# %%
