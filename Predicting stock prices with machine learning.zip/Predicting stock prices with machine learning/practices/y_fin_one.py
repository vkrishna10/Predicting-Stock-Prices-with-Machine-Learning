#%%
import yfinance as yf
import pandas as pd
import numpy as np


aapl_y = yf.Ticker("aapl")
data = np.empty((1,76))
temp = pd.DataFrame(aapl_y.info, index=["aapl"])
temp.head()
#%%
goog_y = yf.Ticker("goog")
data = np.empty((1,76))
temp2 = pd.DataFrame(goog_y.info, index=["goog"])
#%%
temp2.set_index(temp2["symbol"])
del temp2["symbol"]


# %%
full = pd.concat([temp, temp2])
# %%
full.head()

# %%
del full["symbol"]
#%%
full
#%%
