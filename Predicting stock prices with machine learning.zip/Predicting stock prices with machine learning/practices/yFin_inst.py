#%%
import yfinance as yf
import pandas as pd
import numpy as np
# %%
tickers_list = ["aapl","goog", "amzn", "BAC", "BA"] # add any ticker symbols you want
#%%
data = np.empty((1,76))
df = pd.DataFrame(data)

dfs = []

#%%
for ticker in tickers_list:
    temp_y = yf.Ticker(ticker)
    df_t = pd.DataFrame(temp_y.info, index = ["temp"])
    
    df_t.set_index(df_t["symbol"], drop=True, inplace=True)
    del df_t["symbol"]
    dfs.append(df_t)

#%%
df = pd.concat(dfs)
df
# %%
a = []
for col in df.columns:
    a.append(col)

# %%
print(a)
# %%
a.sort()
# %%
print(a, sep="\n")
# %%
