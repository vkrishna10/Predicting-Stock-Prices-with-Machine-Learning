#%%
import requests
import json
import pandas as pd
import numpy as np
# %%

csv_file = np.genfromtxt('.csv', 
                          delimiter=',', dtype=str)
top_row = csv_file[:,0].tolist()
